/*

Created By @MexxTampan
Github @MexxModss

*/

const fs = require('fs');
const path = require('path');
const payment = require('../lib/payment');

const DB_DIR = path.join(__dirname, '..', 'database');
const OWNER = String(global.config.owner_Id);
const sessions = new Map();
const checking = new Set();
const EXPIRE_MS = 30 * 60 * 1000;
const STORE_BANNER = path.join(__dirname, '..', 'media', 'store_banner.png');
// Folder backup file produk (zip, txt, foto, dll). Ikut di-download bersama folder database.
const FILES_DIR = path.join(__dirname, '..', 'product_files');

function localPath(rel) {
  if (!rel) return null;
  const full = path.join(FILES_DIR, rel);
  return full.startsWith(FILES_DIR) && fs.existsSync(full) ? full : null;
}
// Download file dari Telegram ke folder product_files. Mengembalikan nama relatif atau null (mis. file >20MB).
async function saveLocal(bot, fileId, originalName) {
  try {
    fs.mkdirSync(FILES_DIR, { recursive: true });
    const tmp = await bot.downloadFile(fileId, FILES_DIR);
    const base = String(originalName || path.basename(tmp)).replace(/[^\w.\- ]/g, '_').slice(0, 120);
    const name = Date.now().toString(36) + '-' + base;
    fs.renameSync(tmp, path.join(FILES_DIR, name));
    return name;
  } catch (e) { console.error('[STORE SAVE LOCAL]', e.message); return null; }
}
async function sendFile(bot, method, userId, d, options) {
  const loc = localPath(d.localFile);
  if (loc) {
    try { return await bot[method](userId, fs.createReadStream(loc), options, { filename: d.fileName || path.basename(loc) }); }
    catch (e) { console.error('[STORE LOCAL SEND]', e.message); }
  }
  if (!d.fileId) throw new Error('File produk tidak ditemukan di product_files dan fileId kosong.');
  return bot[method](userId, d.fileId, options);
}
function photoSource(p) {
  const loc = localPath(p.photoLocal);
  if (loc) return () => fs.createReadStream(loc);
  return p.photo || null;
}

function read(name, fallback) {
  try { return JSON.parse(fs.readFileSync(path.join(DB_DIR, name), 'utf8')); }
  catch (_) { return fallback; }
}
function write(name, value) {
  fs.mkdirSync(DB_DIR, { recursive: true });
  fs.writeFileSync(path.join(DB_DIR, name), JSON.stringify(value, null, 2));
}
function products() { return read('products.json', { products: [] }).products || []; }
function saveProducts(items) { write('products.json', { products: items }); }
function orders() { return read('orders.json', { orders: [] }).orders || []; }
function saveOrders(items) { write('orders.json', { orders: items }); }
function methods() { return read('payment_methods.json', { methods: [] }).methods || []; }
function saveMethods(items) { write('payment_methods.json', { methods: items }); }
function settings() { return read('store_settings.json', { autoEnabled: true, manualEnabled: true, autoApiKey: '' }); }
function saveSettings(value) { write('store_settings.json', value); }
function isOwner(id) { return String(id) === OWNER; }
function hasAutoKey() { const key = String(global.config.lzpediaApiKey || '').trim(); return Boolean(key && !['key_kamu', 'ISI_API_KEY_LZPEDIA', 'YOUR_API_KEY'].includes(key)); }
function esc(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function money(n) { return 'Rp' + Number(n || 0).toLocaleString('id-ID'); }
function id(prefix) { return prefix + '-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 7).toUpperCase(); }
function keyboard(rows) { return { inline_keyboard: rows }; }
async function say(bot, chatId, text, markup) {
  return bot.sendMessage(chatId, text, { parse_mode: 'HTML', disable_web_page_preview: true, ...(markup ? { reply_markup: markup } : {}) });
}
async function edit(bot, chatId, messageId, text, markup) {
  const options = { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', disable_web_page_preview: true, ...(markup ? { reply_markup: markup } : {}) };
  try { return await bot.editMessageCaption(text, options); }
  catch (captionError) {
    try { return await bot.editMessageText(text, options); }
    catch (textError) {
      // Jangan kirim pesan baru saat edit gagal: mencegah katalog menumpuk/spam.
      console.error('[STORE EDIT]', textError.message || captionError.message);
      return null;
    }
  }
}
async function showPhoto(bot, message, media, caption, markup) {
  const chatId = message.chat.id; const messageId = message.message_id;
  const bannerOk = fs.existsSync(STORE_BANNER);
  const source = () => media ? (typeof media === 'function' ? media() : media) : (bannerOk ? fs.createReadStream(STORE_BANNER) : null);
  const base = { parse_mode: 'HTML', ...(markup ? { reply_markup: markup } : {}) };
  // Pesan asal sudah foto -> cukup ganti media + caption.
  if (message.photo && source()) {
    try {
      return await bot.editMessageMedia({ type: 'photo', media: source(), caption, parse_mode: 'HTML' }, { chat_id: chatId, message_id: messageId, ...(markup ? { reply_markup: markup } : {}) });
    } catch (e) {
      if (/not modified/i.test(e.message || '')) return null;
      console.error('[STORE MEDIA EDIT]', e.message);
    }
  }
  // Pesan asal teks (Telegram tidak bisa ubah teks -> foto): kirim foto baru lalu hapus pesan lama.
  const first = source();
  if (first) {
    try {
      const sent = await bot.sendPhoto(chatId, first, { caption, ...base });
      try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
      return sent;
    } catch (e) {
      console.error('[STORE SEND PHOTO]', e.message);
      // file_id produk bermasalah -> coba banner toko
      if (media && bannerOk) {
        try {
          const sent = await bot.sendPhoto(chatId, fs.createReadStream(STORE_BANNER), { caption, ...base });
          try { await bot.deleteMessage(chatId, messageId); } catch (_) {}
          return sent;
        } catch (e2) { console.error('[STORE SEND BANNER]', e2.message); }
      }
    }
  }
  return edit(bot, chatId, messageId, caption, markup);
}
async function showStoreHome(bot, message, userId) {
  const text = homeText() + (isOwner(userId) ? '\n\n<b>Menu Owner</b>' : '');
  const markup = isOwner(userId) ? ownerMenu() : productKeyboard();
  return showPhoto(bot, message, null, text, markup);
}
async function showStoreHomeNew(bot, chatId, userId) {
  const text = homeText() + (isOwner(userId) ? '\n\n<b>Menu Owner</b>' : '');
  const markup = isOwner(userId) ? ownerMenu() : productKeyboard();
  if (fs.existsSync(STORE_BANNER)) {
    return bot.sendPhoto(chatId, fs.createReadStream(STORE_BANNER), { caption: text, parse_mode: 'HTML', reply_markup: markup });
  }
  return say(bot, chatId, text, markup);
}
function ownerMenu() {
  return keyboard([
    [{ text: '➕ Tambah Produk', callback_data: 'owner:add' }, { text: '📦 Cek Produk', callback_data: 'owner:products' }],
    [{ text: '💳 Pengaturan Pembayaran', callback_data: 'owner:payments' }, { text: '🧾 Pesanan', callback_data: 'owner:orders' }],
    [{ text: '🏠 Menu Toko', callback_data: 'store:home' }]
  ]);
}
function homeText() {
  const list = products().filter(p => p.active !== false);
  return list.length ? '<b>🛍 DIGITAL PRODUCT STORE</b>\nPilih produk yang ingin dibeli.' : '<b>🛍 DIGITAL PRODUCT STORE</b>\n\nBelum ada produk tersedia saat ini.';
}
function productKeyboard() {
  const list = products().filter(p => p.active !== false);
  const rows = list.map(p => [{ text: `${p.name} — ${money(p.price)}`, callback_data: `product:${p.id}` }]);
  rows.push([{ text: '🔄 Refresh', callback_data: 'store:home' }]);
  // Baris paling bawah: 2 tombol link sejajar kiri-kanan.
  const links = [global.config.saluran1, global.config.saluran2]
    .filter(l => l && l.text && /^https?:\/\//i.test(String(l.url || '')))
    .map(l => ({ text: l.text, url: l.url }));
  if (links.length) rows.push(links);
  if (list.length === 0) rows.unshift([{ text: '📦 Produk belum tersedia', callback_data: 'noop' }]);
  return keyboard(rows);
}
function productDetail(p) {
  return `<b>${esc(p.name)}</b>\n\n${esc(p.description || 'Tidak ada deskripsi.')}\n\n<b>Harga:</b> ${money(p.price)}`;
}
function findOrder(orderId) { return orders().find(o => o.id === orderId); }
function updateOrder(orderId, patch) {
  const list = orders(); const i = list.findIndex(o => o.id === orderId);
  if (i < 0) return null;
  list[i] = { ...list[i], ...patch, updatedAt: new Date().toISOString() };
  saveOrders(list); return list[i];
}

async function deliver(bot, order) {
  if (!order || order.status === 'delivered') return;
  const p = products().find(x => x.id === order.productId) || order.productSnapshot;
  if (!p || !p.delivery) {
    await say(bot, order.userId, `Pembayaran pesanan <code>${esc(order.id)}</code> sudah diterima, tetapi konten produk belum tersedia. Hubungi admin.`);
    updateOrder(order.id, { status: 'paid_delivery_error' });
    return;
  }
  const d = p.delivery;
  const caption = `✅ <b>Pembayaran berhasil!</b>\nProduk: ${esc(p.name)}\nOrder ID: <code>${esc(order.id)}</code>`;
  try {
    if (d.type === 'document') await sendFile(bot, 'sendDocument', order.userId, d, { caption: caption + (d.caption ? `\n\n${esc(d.caption)}` : ''), parse_mode: 'HTML' });
    else if (d.type === 'photo') await sendFile(bot, 'sendPhoto', order.userId, d, { caption: caption + (d.caption ? `\n\n${esc(d.caption)}` : ''), parse_mode: 'HTML' });
    else if (d.type === 'video') await sendFile(bot, 'sendVideo', order.userId, d, { caption: caption + (d.caption ? `\n\n${esc(d.caption)}` : ''), parse_mode: 'HTML' });
    else if (d.type === 'audio') await sendFile(bot, 'sendAudio', order.userId, d, { caption: caption + (d.caption ? `\n\n${esc(d.caption)}` : ''), parse_mode: 'HTML' });
    else await say(bot, order.userId, `${caption}\n\n${esc(d.text || '')}`);
    updateOrder(order.id, { status: 'delivered', deliveredAt: new Date().toISOString() });
    await say(bot, OWNER, `📦 <b>Produk terkirim</b>\nOrder: <code>${esc(order.id)}</code>\nPembeli: <code>${esc(order.userId)}</code>\nProduk: ${esc(p.name)}`);
  } catch (e) {
    console.error('[STORE DELIVERY]', e.message);
    updateOrder(order.id, { status: 'paid_delivery_error', deliveryError: e.message });
    await say(bot, OWNER, `⚠️ Pengiriman gagal untuk <code>${esc(order.id)}</code>. Error: ${esc(e.message)}`);
    await say(bot, order.userId, `Pembayaran diterima, tetapi pengiriman otomatis mengalami kendala. Admin akan membantu pesanan <code>${esc(order.id)}</code>.`);
  }
}

async function checkAutoOrder(bot, order) {
  if (!order || order.status !== 'pending_auto' || checking.has(order.id)) return;
  if (Date.now() > new Date(order.expiresAt).getTime()) {
    updateOrder(order.id, { status: 'expired' });
    await say(bot, order.userId, `Invoice <code>${esc(order.id)}</code> sudah kedaluwarsa. Silakan buat pesanan baru.`);
    return;
  }
  checking.add(order.id);
  try {
    const paid = await payment.cekPaid({ orderId: order.gatewayInvoiceId });
    if (paid) {
      updateOrder(order.id, { status: 'paid', paidAt: new Date().toISOString() });
      await deliver(bot, findOrder(order.id));
    }
  } catch (e) { console.error('[STORE PAYMENT CHECK]', e.message); }
  finally { checking.delete(order.id); }
}

module.exports = (bot) => {
  // Inisialisasi database baru dan migrasi aman tanpa menghapus file historis.
  for (const [file, value] of Object.entries({
    'products.json': { products: [] }, 'orders.json': { orders: [] },
    'payment_methods.json': { methods: [] },
    'store_settings.json': { autoEnabled: true, manualEnabled: true, autoApiKey: '' }
  })) if (!fs.existsSync(path.join(DB_DIR, file))) write(file, value);

  const savedSettings = settings();
  if (savedSettings.autoApiKey) global.config.lzpediaApiKey = savedSettings.autoApiKey;

  bot.on('message', async (msg) => {
    if (!msg || !msg.from || msg.chat.type !== 'private') return;
    const userId = String(msg.from.id); const chatId = msg.chat.id;
    const text = (msg.text || '').trim();
    if (text === '/start' || text === '/menu') {
      sessions.delete(userId);
      await showStoreHomeNew(bot, chatId, userId);
      return;
    }
    if (text === '/sync' && isOwner(userId)) {
      const list = products(); let ok = 0, fail = 0, skip = 0;
      for (const p of list) {
        if (p.photo && !localPath(p.photoLocal)) { const n = await saveLocal(bot, p.photo, 'foto-produk.jpg'); if (n) { p.photoLocal = n; ok++; } else fail++; }
        const d = p.delivery;
        if (d && d.fileId && !localPath(d.localFile)) { const n = await saveLocal(bot, d.fileId, d.fileName || (d.type + '-produk')); if (n) { d.localFile = n; ok++; } else fail++; } else skip++;
      }
      saveProducts(list);
      await say(bot, chatId, `🔄 <b>Sync backup selesai</b>\nBerhasil: ${ok}\nGagal: ${fail}\nSudah ada/dilewati: ${skip}\n\nFile tersimpan di folder <code>product_files</code>.`, ownerMenu()); return;
    }
    if (text === '/owner' && isOwner(userId)) { await say(bot, chatId, '<b>⚙️ OWNER PANEL</b>', ownerMenu()); return; }

    const state = sessions.get(userId);
    if (!state) {
      // Bukti transfer manual dikaitkan dengan order pending milik pengirim.
      const pending = orders().filter(o => String(o.userId) === userId && o.status === 'manual_waiting_proof').sort((a,b) => b.createdAt.localeCompare(a.createdAt))[0];
      if (pending && (msg.photo || msg.document || msg.text)) {
        updateOrder(pending.id, { status: 'manual_review', proofMessageId: msg.message_id, proofText: text || msg.caption || '' });
        try { await bot.copyMessage(OWNER, chatId, msg.message_id); } catch (_) {}
        await say(bot, OWNER, `🧾 <b>Bukti pembayaran masuk</b>\nOrder: <code>${esc(pending.id)}</code>\nPembeli: <code>${userId}</code>\nProduk: ${esc(pending.productSnapshot.name)}`, keyboard([[{ text: '✅ Terima & Kirim Produk', callback_data: `manual:approve:${pending.id}` }, { text: '❌ Tolak', callback_data: `manual:reject:${pending.id}` }]]));
        await say(bot, chatId, `Bukti pembayaran untuk <code>${esc(pending.id)}</code> sudah dikirim ke admin. Tunggu konfirmasi.`);
      }
      return;
    }

    if (state.step === 'add_name' && text) {
      state.data.name = text.slice(0, 80); state.step = 'add_description';
      await say(bot, chatId, 'Kirim deskripsi/keterangan produk.'); return;
    }
    if (state.step === 'add_description' && text) {
      state.data.description = text.slice(0, 1500); state.step = 'add_photo';
      await say(bot, chatId, 'Kirim foto produk atau tekan Skip.', keyboard([[{ text: '⏭ Skip Foto', callback_data: 'owner:skipphoto' }]])); return;
    }
    if (state.step === 'add_photo') {
      if (msg.photo && msg.photo.length) { state.data.photo = msg.photo[msg.photo.length - 1].file_id; state.data.photoLocal = await saveLocal(bot, state.data.photo, 'foto-produk.jpg'); }
      else if (text.toLowerCase() === 'skip') state.data.photo = null;
      else { await say(bot, chatId, 'Kirim foto produk atau tekan tombol Skip.'); return; }
      state.step = 'add_price'; await say(bot, chatId, 'Masukkan harga produk dalam angka Rupiah. Contoh: <code>15000</code>.'); return;
    }
    if (state.step === 'add_price' && text) {
      const price = Number(text.replace(/[^0-9]/g, ''));
      if (!Number.isSafeInteger(price) || price < 1) { await say(bot, chatId, 'Harga tidak valid. Masukkan angka lebih dari 0.'); return; }
      state.data.price = price; state.step = 'add_delivery';
      await say(bot, chatId, 'Kirim isi produk digital. Bisa berupa:\n• Teks atau link\n• File sebagai dokumen\n• Foto, video, atau audio\n\nUntuk file, kirim sebagai dokumen agar file asli tetap terjaga.'); return;
    }
    if (state.step === 'add_delivery') {
      const d = { type: 'text', text: text || msg.caption || '' };
      if (msg.document) { d.type = 'document'; d.fileId = msg.document.file_id; d.fileName = msg.document.file_name || ''; d.caption = msg.caption || ''; }
      else if (msg.photo && msg.photo.length) { d.type = 'photo'; d.fileId = msg.photo[msg.photo.length - 1].file_id; d.caption = msg.caption || ''; }
      else if (msg.video) { d.type = 'video'; d.fileId = msg.video.file_id; d.caption = msg.caption || ''; }
      else if (msg.audio) { d.type = 'audio'; d.fileId = msg.audio.file_id; d.caption = msg.caption || ''; }
      if (!d.text && !d.fileId) { await say(bot, chatId, 'Konten produk kosong. Kirim teks, link, atau file.'); return; }
      if (d.fileId) {
        d.localFile = await saveLocal(bot, d.fileId, d.fileName || (d.type + '-produk'));
        if (!d.localFile) await say(bot, chatId, '⚠️ File gagal di-backup ke folder product_files (Telegram membatasi bot download maksimal 20MB). Produk tetap bisa dikirim lewat Telegram, tapi tidak ada backup lokal. Taruh file manual di folder product_files lalu isi localFile di products.json jika perlu.');
      }
      state.data.delivery = d; state.step = 'add_confirm';
      const p = state.data;
      const preview = `<b>Preview Produk</b>\nNama: ${esc(p.name)}\nDeskripsi: ${esc(p.description)}\nHarga: ${money(p.price)}\nFoto: ${p.photo ? 'Ada' : 'Tidak ada'}\nPengiriman: ${esc(d.type)}${d.fileId ? '\\nBackup lokal: ' + (d.localFile ? 'Ada' : 'Tidak ada') : ''}\nKonten: ${esc((d.text || d.caption || '').slice(0, 250))}`;
      await say(bot, chatId, preview, keyboard([[{ text: '💾 Simpan Produk', callback_data: 'owner:saveproduct' }, { text: '❌ Batal', callback_data: 'owner:cancel' }]])); return;
    }
    if (state.step === 'add_method_name' && text) {
      state.data.name = text.slice(0, 50); state.step = 'add_method_instructions';
      await say(bot, chatId, 'Kirim instruksi pembayaran. Contoh: nama penerima, nomor DANA/GoPay, atau keterangan transfer.'); return;
    }
    if (state.step === 'add_method_instructions' && text) {
      state.data.instructions = text.slice(0, 1200); state.step = 'add_method_photo';
      await say(bot, chatId, 'Kirim foto QRIS (opsional), atau tekan Skip.', keyboard([[{ text: '⏭ Skip Foto', callback_data: 'owner:skipmethodphoto' }]])); return;
    }
    if (state.step === 'add_method_photo') {
      if (msg.photo && msg.photo.length) state.data.photo = msg.photo[msg.photo.length - 1].file_id;
      else if (text.toLowerCase() === 'skip') state.data.photo = null;
      else { await say(bot, chatId, 'Kirim foto QRIS atau tekan Skip.'); return; }
      const list = methods(); list.push({ id: id('PAY'), ...state.data, active: true }); saveMethods(list);
      sessions.delete(userId); await say(bot, chatId, '✅ Metode pembayaran manual berhasil ditambahkan.', ownerMenu()); return;
    }
    if (state.step === 'set_gateway_key' && text) {
      const s = settings(); s.autoApiKey = text; s.autoEnabled = true; saveSettings(s); global.config.lzpediaApiKey = text;
      sessions.delete(userId); await say(bot, chatId, '✅ API key Auto QRIS tersimpan. Metode Auto QRIS aktif.', ownerMenu()); return;
    }
  });

  bot.on('callback_query', async (q) => {
    const data = q.data || ''; const userId = String(q.from.id); const chatId = q.message.chat.id; const messageId = q.message.message_id;
    const answer = async (t) => { try { await bot.answerCallbackQuery(q.id, t ? { text: t } : {}); } catch (_) {} };
    if (data === 'noop') { await answer(); return; }
    if (data === 'store:home') { await answer(); await showStoreHome(bot, q.message, userId); return; }

    if (data.startsWith('product:')) {
      const p = products().find(x => x.id === data.slice(8) && x.active !== false);
      if (!p) { await answer('Produk tidak ditemukan.'); return; }
      await answer();
      const rows = [];
      const s = settings();
      if (s.autoEnabled && hasAutoKey()) rows.push([{ text: '⚡ Auto QRIS', callback_data: `buy:auto:${p.id}` }]);
      if (s.manualEnabled && methods().some(m => m.active !== false)) rows.push([{ text: '💳 Pembayaran Manual', callback_data: `buy:manual:${p.id}` }]);
      rows.push([{ text: '⬅️ Kembali', callback_data: 'store:home' }]);
      await showPhoto(bot, q.message, photoSource(p), productDetail(p), keyboard(rows));
      return;
    }

    if (data.startsWith('buy:auto:')) {
      const p = products().find(x => x.id === data.slice(9) && x.active !== false);
      if (!p) { await answer('Produk tidak tersedia.'); return; }
      await answer('Membuat invoice...');
      try {
        const invoice = await payment.createPayment(p.price);
        const order = { id: id('ORD'), userId, productId: p.id, productSnapshot: p, amount: Number(invoice.amount || p.price), paymentType: 'auto_qris', gatewayInvoiceId: invoice.orderId, status: 'pending_auto', createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + EXPIRE_MS).toISOString() };
        const list = orders(); list.push(order); saveOrders(list);
        const caption = `🧾 <b>INVOICE PEMBAYARAN</b>\nOrder: <code>${esc(order.id)}</code>\nProduk: ${esc(p.name)}\nTotal: <b>${money(order.amount)}</b>\n\nScan QRIS di bawah ini. Pembayaran diverifikasi otomatis.\nBatas pembayaran: 30 menit.`;
        if (invoice.qris && /^https?:\/\//i.test(invoice.qris)) await bot.sendPhoto(chatId, invoice.qris, { caption, parse_mode: 'HTML' });
        else {
          const paymentInfo = invoice.qris ? `\nQRIS: ${esc(invoice.qris)}` : (invoice.paymentLink ? `\nLink pembayaran: ${esc(invoice.paymentLink)}` : '');
          await say(bot, chatId, caption + paymentInfo);
        }
        await say(bot, OWNER, `🛒 <b>Order Auto QRIS baru</b>\nOrder: <code>${esc(order.id)}</code>\nPembeli: <code>${userId}</code>\nProduk: ${esc(p.name)}\nTotal: ${money(order.amount)}`);
        checkAutoOrder(bot, order);
      } catch (e) { console.error('[CREATE INVOICE]', e.message); await say(bot, chatId, `Gagal membuat invoice: ${esc(e.message)}`); }
      return;
    }

    if (data.startsWith('buy:manual:')) {
      const p = products().find(x => x.id === data.slice(11) && x.active !== false);
      if (!p) { await answer('Produk tidak tersedia.'); return; }
      const list = methods().filter(m => m.active !== false);
      if (!list.length) { await answer('Metode manual belum tersedia.'); return; }
      await answer();
      const rows = list.map(m => [{ text: m.name, callback_data: `manualmethod:${p.id}:${m.id}` }]);
      rows.push([{ text: '⬅️ Kembali', callback_data: `product:${p.id}` }]);
      await edit(bot, chatId, messageId, `${productDetail(p)}\n\nPilih metode pembayaran:`, keyboard(rows)); return;
    }

    if (data.startsWith('manualmethod:')) {
      const [, productId, methodId] = data.split(':');
      const p = products().find(x => x.id === productId && x.active !== false);
      const m = methods().find(x => x.id === methodId && x.active !== false);
      if (!p || !m) { await answer('Data tidak ditemukan.'); return; }
      const order = { id: id('ORD'), userId, productId: p.id, productSnapshot: p, amount: p.price, paymentType: 'manual', methodId: m.id, status: 'manual_waiting_proof', createdAt: new Date().toISOString(), expiresAt: new Date(Date.now() + EXPIRE_MS).toISOString() };
      const list = orders(); list.push(order); saveOrders(list); await answer();
      const caption = `🧾 <b>INSTRUKSI PEMBAYARAN</b>\nOrder: <code>${esc(order.id)}</code>\nProduk: ${esc(p.name)}\nTotal: <b>${money(p.price)}</b>\nMetode: <b>${esc(m.name)}</b>\n\n${esc(m.instructions)}\n\nSetelah transfer, kirim bukti pembayaran ke chat ini. Admin akan memeriksa sebelum produk dikirim. Batas 30 menit.`;
      if (m.photo) await bot.sendPhoto(chatId, m.photo, { caption, parse_mode: 'HTML' }); else await say(bot, chatId, caption);
      await say(bot, OWNER, `🛒 <b>Order manual baru</b>\nOrder: <code>${esc(order.id)}</code>\nPembeli: <code>${userId}</code>\nProduk: ${esc(p.name)}\nTotal: ${money(p.price)}\nMetode: ${esc(m.name)}`);
      return;
    }

    if (data.startsWith('manual:approve:') || data.startsWith('manual:reject:')) {
      if (!isOwner(userId)) { await answer('Khusus owner.'); return; }
      const approve = data.startsWith('manual:approve:'); const orderId = data.split(':').slice(2).join(':');
      const order = findOrder(orderId);
      if (!order || order.status !== 'manual_review') { await answer('Pesanan sudah diproses atau tidak ditemukan.'); return; }
      await answer(approve ? 'Pembayaran diterima.' : 'Pembayaran ditolak.');
      if (approve) { updateOrder(orderId, { status: 'paid', approvedBy: userId, paidAt: new Date().toISOString() }); await say(bot, order.userId, `✅ Pembayaran manual diterima untuk <code>${esc(orderId)}</code>. Produk akan dikirim.`); await deliver(bot, findOrder(orderId)); }
      else { updateOrder(orderId, { status: 'rejected', rejectedBy: userId }); await say(bot, order.userId, `❌ Bukti pembayaran untuk <code>${esc(orderId)}</code> ditolak admin. Silakan hubungi admin.`); }
      try { await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: chatId, message_id: messageId }); } catch (_) {}
      return;
    }

    if (!isOwner(userId)) { await answer('Menu ini khusus owner.'); return; }
    if (data === 'owner:add') { sessions.set(userId, { step: 'add_name', data: {} }); await answer(); await say(bot, chatId, 'Masukkan nama produk baru.'); return; }
    if (data === 'owner:skipphoto') { const st = sessions.get(userId); if (!st || st.step !== 'add_photo') { await answer('Sesi tidak ditemukan.'); return; } st.data.photo = null; st.step = 'add_price'; await answer(); await say(bot, chatId, 'Masukkan harga produk dalam angka Rupiah.'); return; }
    if (data === 'owner:skipmethodphoto') { const st = sessions.get(userId); if (!st || st.step !== 'add_method_photo') { await answer('Sesi tidak ditemukan.'); return; } st.data.photo = null; const list = methods(); list.push({ id: id('PAY'), ...st.data, active: true }); saveMethods(list); sessions.delete(userId); await answer('Metode tersimpan.'); await say(bot, chatId, '✅ Metode pembayaran manual ditambahkan.', ownerMenu()); return; }
    if (data === 'owner:saveproduct') {
      const st = sessions.get(userId); if (!st || st.step !== 'add_confirm') { await answer('Sesi tidak ditemukan.'); return; }
      const list = products(); const p = { id: id('PRD'), ...st.data, active: true, createdAt: new Date().toISOString() }; list.push(p); saveProducts(list); sessions.delete(userId); await answer('Produk disimpan.'); await say(bot, chatId, `✅ Produk <b>${esc(p.name)}</b> berhasil ditambahkan.`, ownerMenu()); return;
    }
    if (data === 'owner:cancel') { sessions.delete(userId); await answer('Dibatalkan.'); await say(bot, chatId, 'Proses dibatalkan.', ownerMenu()); return; }
    if (data === 'owner:products') {
      await answer(); const list = products();
      if (!list.length) { await say(bot, chatId, 'Belum ada produk. Tekan Tambah Produk untuk membuat katalog.', ownerMenu()); return; }
      for (const p of list) await say(bot, chatId, `<b>${esc(p.name)}</b>\nID: <code>${esc(p.id)}</code>\nHarga: ${money(p.price)}\nStatus: ${p.active === false ? 'Nonaktif' : 'Aktif'}`, keyboard([[{ text: p.active === false ? '🟢 Aktifkan' : '⏸ Nonaktifkan', callback_data: `owner:toggle:${p.id}` }, { text: '🗑 Hapus', callback_data: `owner:delete:${p.id}` }]]));
      await say(bot, chatId, 'Menu Owner', ownerMenu()); return;
    }
    if (data.startsWith('owner:toggle:')) {
      const productId = data.slice('owner:toggle:'.length); const list = products(); const p = list.find(x => x.id === productId);
      if (p) { p.active = p.active === false; saveProducts(list); }
      await answer('Status produk diperbarui.'); await say(bot, chatId, p ? `${esc(p.name)}: ${p.active ? 'Aktif' : 'Nonaktif'}` : 'Produk tidak ditemukan.', ownerMenu()); return;
    }
    if (data.startsWith('owner:delete:')) {
      const productId = data.slice('owner:delete:'.length); const list = products(); const p = list.find(x => x.id === productId);
      if (p) {
        saveProducts(list.filter(x => x.id !== productId));
        for (const rel of [p.photoLocal, p.delivery && p.delivery.localFile]) { const f = localPath(rel); if (f) { try { fs.unlinkSync(f); } catch (_) {} } }
      }
      await answer('Produk dihapus.'); await say(bot, chatId, p ? `Produk ${esc(p.name)} dihapus.` : 'Produk tidak ditemukan.', ownerMenu()); return;
    }
    if (data === 'owner:payments') {
      await answer(); const s = settings();
      await say(bot, chatId, `<b>💳 PENGATURAN PEMBAYARAN</b>\nAuto QRIS: ${s.autoEnabled ? 'Aktif' : 'Nonaktif'}\nManual: ${s.manualEnabled ? 'Aktif' : 'Nonaktif'}\nMetode manual: ${methods().length}\nAPI Key Auto QRIS: ${(s.autoApiKey || hasAutoKey()) ? 'Sudah diatur' : 'Belum diatur'}`, keyboard([
        [{ text: '🔑 Atur API Key Auto QRIS', callback_data: 'owner:setkey' }],
        [{ text: `${s.autoEnabled ? '⏸ Matikan' : '🟢 Aktifkan'} Auto QRIS`, callback_data: 'owner:toggleauto' }],
        [{ text: `${s.manualEnabled ? '⏸ Matikan' : '🟢 Aktifkan'} Manual`, callback_data: 'owner:togglemanual' }],
        [{ text: '➕ Tambah Metode Manual', callback_data: 'owner:addmethod' }],
        ...methods().map(m => [{ text: `🗑 Hapus ${m.name}`, callback_data: `owner:delmethod:${m.id}` }]),
        [{ text: '⬅️ Menu Owner', callback_data: 'owner:back' }]
      ])); return;
    }
    if (data === 'owner:setkey') { sessions.set(userId, { step: 'set_gateway_key', data: {} }); await answer(); await say(bot, chatId, 'Kirim API key Lz Pedia. Nilai akan disimpan lokal di database/store_settings.json.'); return; }
    if (data === 'owner:toggleauto' || data === 'owner:togglemanual') { const s = settings(); if (data.endsWith('auto')) s.autoEnabled = !s.autoEnabled; else s.manualEnabled = !s.manualEnabled; saveSettings(s); await answer('Pengaturan disimpan.'); await say(bot, chatId, 'Pengaturan pembayaran diperbarui.', ownerMenu()); return; }
    if (data === 'owner:addmethod') { sessions.set(userId, { step: 'add_method_name', data: {} }); await answer(); await say(bot, chatId, 'Masukkan nama metode pembayaran, misalnya DANA, GoPay, BCA, atau QRIS.'); return; }
    if (data.startsWith('owner:delmethod:')) { const methodId = data.slice('owner:delmethod:'.length); saveMethods(methods().filter(m => m.id !== methodId)); await answer('Metode dihapus.'); await say(bot, chatId, 'Metode pembayaran diperbarui.', ownerMenu()); return; }
    if (data === 'owner:orders') {
      await answer(); const list = orders().slice(-15).reverse();
      if (!list.length) { await say(bot, chatId, 'Belum ada pesanan.', ownerMenu()); return; }
      for (const o of list) await say(bot, chatId, `Order: <code>${esc(o.id)}</code>\nProduk: ${esc(o.productSnapshot.name)}\nPembeli: <code>${esc(o.userId)}</code>\nTotal: ${money(o.amount)}\nStatus: <b>${esc(o.status)}</b>`);
      await say(bot, chatId, 'Menu Owner', ownerMenu()); return;
    }
    if (data === 'owner:back') { await answer(); await say(bot, chatId, '<b>OWNER PANEL</b>', ownerMenu()); return; }
    await answer();
  });

  // Polling order auto QRIS aktif dan pending tetap dipulihkan setelah restart.
  setInterval(() => {
    for (const order of orders().filter(o => o.status === 'pending_auto')) checkAutoOrder(bot, order);
    for (const order of orders().filter(o => o.status === 'manual_waiting_proof' && Date.now() > new Date(o.expiresAt).getTime())) updateOrder(order.id, { status: 'expired' });
  }, 15000);
};
