/*

Created By @MexxTampan
Github @MexxModss

*/

module.exports = {
  token_Bot: 'BOT_TOKEN',
  owner_Id: 'ID_OWNER',
  botname: 'Digital Store',
  version: '1.0.0',
  saluran1: { text: 'Testimoni', url: 'https://t.me/mexxoffc' },
  saluran2: { text: 'Informasi', url: 'https://t.me/mexxhacking' },
  lzpediaApiKey: 'APIKEY_API' 
};

// https://app.lzpedia.my.id
// ambil apikey dilink diatas