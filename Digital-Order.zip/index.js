/*

Created By @MexxTampan
Github @MexxModss

*/

process.env.NTBA_FIX_319 = '1';
const TeleBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const https = require('https');
const os = require('os');
const config = require('./config');
const db = require('./lib/database');
const utils = require('./lib/utils');

global.config = config;
global.db = db;
global.utils = utils;
global.bot = null;

process.on('uncaughtException', (error) => {
  utils.writeLog(error, 'UNCAUGHT_EXCEPTION');
  console.error(chalk.red.bold('⚠️ Uncaught Exception, bot melanjutkan...'));
});

process.on('unhandledRejection', (reason) => {
  utils.writeLog(reason, 'UNHANDLED_REJECTION');
  console.error(chalk.red.bold('⚠️ Unhandled Rejection, bot melanjutkan...'));
});

const agent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 1000,
  maxSockets: 10,
  maxFreeSockets: 5,
  timeout: 60000,
});

const tokenBot = config.token_Bot;
const botInstance = new TeleBot(tokenBot, {
  polling: {
    params: {
      timeout: 10
    }
  },
  request: {
    agent: agent
  }
});
global.bot = botInstance;
global.botUsername = null;
global.botId = null;

botInstance.getMe().then((me) => {
  global.botUsername = me.username;
  global.botId = me.id;
}).catch(() => {});

const processedMsgKeys = new Set();
const originalEmit = botInstance.emit;

botInstance.emit = function (type, ...args) {
  if (type === 'message' && args[0]) {
    const msg = args[0];
    if (msg.from && msg.from.is_bot) return false;
    const msgKey = `${msg.chat.id}_${msg.message_id}`;
    if (processedMsgKeys.has(msgKey)) {
      return false;
    }
    processedMsgKeys.add(msgKey);
    setTimeout(() => processedMsgKeys.delete(msgKey), 3000);
  }
  return originalEmit.apply(this, [type, ...args]);
};

const dbDir = path.join(__dirname, 'database');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir);
}

const dbFiles = [
  'users.json',
  'transactions.json',
  'products.json',
  'orders.json',
  'payment_methods.json',
  'store_settings.json'
];

dbFiles.forEach(file => {
  const filePath = path.join(dbDir, file);
  if (!fs.existsSync(filePath)) {
    let initialData = {};
    if (file === 'users.json') initialData = { users: [] };
    else if (file === 'transactions.json') initialData = { transactions: [] };
    else if (file === 'products.json') initialData = { products: [] };
    else if (file === 'orders.json') initialData = { orders: [] };
    else if (file === 'payment_methods.json') initialData = { methods: [] };
    else if (file === 'store_settings.json') initialData = { autoEnabled: true, manualEnabled: true, autoApiKey: '' };
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2));
  }
});

function loadPlugins(bot) {
  const pluginsDir = path.join(__dirname, 'plugins');
  if (!fs.existsSync(pluginsDir)) {
    console.error(chalk.red('❌ Folder plugins tidak ditemukan!'));
    return;
  }

  bot.removeAllListeners('message');
  bot.removeAllListeners('callback_query');
  bot.removeAllListeners('text');

  const files = fs.readdirSync(pluginsDir);
  let loaded = 0;
  for (const file of files) {
    if (file.endsWith('.js')) {
      try {
        const plugin = require(path.join(pluginsDir, file));
        if (typeof plugin === 'function') {
          plugin(bot);
        } else if (plugin.register) {
          plugin.register(bot);
        }
        loaded++;
      } catch (err) {
        console.error(chalk.red(`❌ Gagal load plugin ${file}:`), err.message);
      }
    }
  }
  console.log(chalk.green(`✅ ${loaded} plugin dimuat.`));
}

loadPlugins(botInstance);

botInstance.on('polling_error', (error) => {
  console.error(chalk.red(`[POLLING ERROR] ${error.message}`));
});

const colors = {
  green: chalk.green,
  white: chalk.white,
  yellow: chalk.yellow,
  gray: chalk.gray,
  cyan: chalk.cyan,
  bgBlue: chalk.bgBlue,
  gold: chalk.yellowBright
};

const line = '━'.repeat(45);
const doubleLine = '═'.repeat(45);
const nowWIB = utils.nowWIB();

console.log(colors.gold(doubleLine));
console.log(colors.white(`  🚀 ${colors.bgBlue(' BOT DIGITAL ')}`));
console.log(colors.gold(doubleLine));
console.log(colors.white(`  📱 ${colors.bgBlue(' BOT INFO ')}`));
console.log(colors.white(`  • Name  : ${colors.green(config.botname)}`));
console.log(colors.white(`  • Ver   : ${colors.green(config.version)}`));
console.log(colors.white(`  • Node  : ${colors.green(process.version.split('.')[0])}`));
console.log(colors.white(`  • Owner : ${colors.yellow(config.owner_Id)}`));
console.log(colors.white(`  • Start : ${colors.gray(nowWIB)}`));
console.log(colors.gold(line));
console.log(colors.white(`  ⚙️ ${colors.bgBlue(' SISTEM ')}`));
console.log(colors.white(`  • OS    : ${colors.cyan(os.platform())}`));
console.log(colors.white(`  • Host  : ${colors.cyan(os.hostname().substring(0, 20))}`));
console.log(colors.white(`  • CPU   : ${colors.cyan(os.cpus().length)} Core`));
console.log(colors.white(`  • RAM   : ${colors.cyan((os.totalmem() / 1024 / 1024 / 1024).toFixed(2))} GB`));
console.log(colors.gold(line));
console.log(colors.white(`  🔌 ${colors.bgBlue(' MODUL ')}`));
console.log(colors.white(`  • DB     : ${colors.green('✓ OK')}`));
console.log(colors.white(`  • Store  : ${colors.green('✓ Digital Product AutoOrder')}`));
console.log(colors.white(`  • Payment : ${colors.green('✓ Auto QRIS + Manual')}`));
console.log(colors.white(`  • Plugins: ${colors.green('✓ Loaded')}`));
console.log(colors.gold(doubleLine));